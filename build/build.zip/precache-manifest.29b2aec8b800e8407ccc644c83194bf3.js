self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "232c83d728f4742e2cc7840c32ce33d3",
    "url": "/index.html"
  },
  {
    "revision": "386937532d14da57dac4",
    "url": "/static/css/2.d58fcd6a.chunk.css"
  },
  {
    "revision": "6e17d0cc7cb07cc88986",
    "url": "/static/css/main.6ef4c5a1.chunk.css"
  },
  {
    "revision": "386937532d14da57dac4",
    "url": "/static/js/2.5f534dad.chunk.js"
  },
  {
    "revision": "a52d65c95a2d7ffcb9ff212c4d38dff4",
    "url": "/static/js/2.5f534dad.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6e17d0cc7cb07cc88986",
    "url": "/static/js/main.c7e336a5.chunk.js"
  },
  {
    "revision": "bd3355da4c78dac6e05f",
    "url": "/static/js/runtime-main.e4165761.js"
  },
  {
    "revision": "990f4ad6a6013afb0299be872adc4d38",
    "url": "/static/media/GarethBale.990f4ad6.webp"
  },
  {
    "revision": "d2eb9ffd5005504289b403e2a93474c3",
    "url": "/static/media/LionelMessi.d2eb9ffd.webp"
  },
  {
    "revision": "2acf79c42c7bc610498c5a3f3a385de5",
    "url": "/static/media/logo.2acf79c4.webp"
  },
  {
    "revision": "9b078fe7cfbd471d29fa95ba88943ac4",
    "url": "/static/media/neymar.9b078fe7.webp"
  },
  {
    "revision": "1a0c3e423c01df0cdbb557b06f70a862",
    "url": "/static/media/ronaldo.1a0c3e42.webp"
  }
]);